# Dead Code Detection: How Code Graphs Give AI Agents X-Ray Vision

**TL;DR:** Pre-computed code graphs improve AI agent dead code detection from 17% to 92% recall on real-world codebases, while reducing costs by 24x and time by 8x.

---

## Abstract

We evaluate the effectiveness of pre-computed code graphs for AI-assisted dead code detection. Using two datasets—a synthetic Express.js application (35 files, 102 dead code items) and a real-world Next.js application (576 files, 12 verified dead code items from a merged PR)—we compare Claude Sonnet 4's performance with and without access to Supermodel's dead code analysis.

**Key findings:**
- On real-world code, graph-enhanced agents achieve **91.7% recall** vs **16.7% baseline** (5.5x improvement)
- Cost reduction of **24x** ($0.11 vs $2.64 per analysis)
- Speed improvement of **8x** (42s vs 343s)
- Tool call reduction of **30x** (6 vs 184 calls)

---

## 1. Introduction

### 1.1 The Problem

Dead code—functions, classes, and variables that exist but are never executed—accumulates in codebases over time. It increases maintenance burden, confuses developers, and can hide security vulnerabilities. Finding dead code manually is tedious; finding it with AI agents is promising but faces a fundamental challenge: **context window limitations**.

An AI agent tasked with finding dead code must:
1. Enumerate all declarations in the codebase
2. Trace all call paths to determine reachability
3. Account for framework patterns (event handlers, decorators, dynamic imports)

For a 576-file codebase, this requires examining thousands of files and relationships—far exceeding what fits in a context window through naive search.

### 1.2 Our Hypothesis

**Pre-computing a code graph and providing it to the AI agent will dramatically improve dead code detection performance** by eliminating the search problem and providing semantic relationships directly.

### 1.3 What is Supermodel?

Supermodel is a code intelligence platform that parses source code into structured graphs using tree-sitter. The dead code analysis endpoint:

1. **Parses the codebase** - Extracts all functions, classes, types, and variables
2. **Builds import/export relationships** - Resolves which symbols are used where
3. **Identifies entry points** - Framework patterns (index.ts, page.tsx), exported API surfaces
4. **Performs BFS reachability** - Starting from entry points, marks everything reachable as "alive"
5. **Reports candidates** - Everything not marked alive is a dead code candidate

```bash
curl -X POST "https://api.supermodeltools.com/v1/analysis/dead-code" \
  -H "X-Api-Key: $API_KEY" \
  -F "file=@repo.zip"
```

---

## 2. Methodology

### 2.1 Benchmark Framework

We use [mcpbr](https://github.com/greynewell/mcpbr) (Model Context Protocol Benchmark Runner), a framework for evaluating AI agents on software engineering tasks. mcpbr:

- Provides isolated environments for each task
- Exposes tools via MCP (Model Context Protocol)
- Measures precision, recall, F1 score, cost, latency, and tool usage
- Supports A/B comparison between configurations

### 2.2 Experimental Setup

| Parameter | Value |
|-----------|-------|
| Model | Claude Sonnet 4 (claude-sonnet-4-20250514) |
| Provider | Anthropic API |
| Agent Harness | Claude Code |
| Timeout | 300s (with graph), 900s (baseline) |
| Max Iterations | 10 (with graph), 50 (baseline) |

**Tools Available (Both Conditions):**
- File system access (read, write, glob)
- Grep/search
- Bash command execution

**Additional Tool (Graph Condition):**
- Pre-computed dead code analysis JSON in `.supermodel/dead-code-analysis.json`

### 2.3 Agent Prompts

**Baseline Prompt:**
```
You are an expert software architect. Find all dead code in the codebase.

Dead code includes:
- Functions that are never called
- Classes that are never instantiated
- Variables that are never used

Update REPORT.json with your findings.
```

**Graph-Enhanced Prompt:**
```
You are an expert software architect. Find all dead code in the codebase.

The analysis has already been computed for you in `.supermodel/dead-code-analysis.json`.

STEPS:
1. Read `.supermodel/dead-code-analysis.json`
2. Extract the "dead_code_candidates" array
3. Write REPORT.json with these candidates
```

### 2.4 Evaluation Metrics

- **Precision** = True Positives / (True Positives + False Positives)
- **Recall** = True Positives / (True Positives + False Negatives)
- **F1 Score** = 2 × (Precision × Recall) / (Precision + Recall)
- **Cost** = Anthropic API charges for the run
- **Runtime** = Wall-clock time to completion
- **Tool Calls** = Number of tool invocations

---

## 3. Datasets

### 3.1 Dataset 1: typescript-express-app (Synthetic)

A purpose-built Express.js e-commerce API with intentionally planted dead code patterns.

| Metric | Value |
|--------|-------|
| Total Files | 35 |
| Total Functions | 120 |
| Dead Code Items | 102 |
| Language | TypeScript |
| Framework | Express.js |

**Dead code categories:**
- Legacy integration code (removed PHP backend)
- Deprecated authentication methods (session → JWT migration)
- Feature flags for cancelled features
- Utility functions replaced by libraries
- Old API response formatters

**Example dead code (from ground truth):**
```typescript
// src/utils/crypto.ts - Line 22
// Reason: "Insecure, removed"
export function hashMd5(input: string): string {
  return crypto.createHash('md5').update(input).digest('hex');
}

// src/middleware/auth.ts - Line 39
// Reason: "Replaced by OAuth"
export function apiKeyAuth(req, res, next) {
  const apiKey = req.headers['x-api-key'];
  // ... validation logic
}
```

### 3.2 Dataset 2: antiwork-helper (Real-World)

A production Next.js application from [Helper](https://helper.ai) (655 GitHub stars), an open-source customer support platform.

| Metric | Value |
|--------|-------|
| Total Files | 576 |
| Language | TypeScript |
| Framework | Next.js 14 (App Router) |
| Source | [github.com/antiwork/helper](https://github.com/antiwork/helper) |

**Ground Truth Source: [PR #527](https://github.com/antiwork/helper/pull/527)**

This PR, titled "chore: remove unused code from helper UI", was merged on June 21, 2025. It removed 106 lines across 7 files, deleting components that static analysis identified as unused.

| Dead Code Item | File | Type | Lines |
|----------------|------|------|-------|
| `Divider` | components/divider.tsx | React Component | 15 |
| `DividerProps` | components/divider.tsx | Type | - |
| `OAuthButton` | components/oauthButton.tsx | React Component | 21 |
| `OAuthButtonProps` | components/oauthButton.tsx | Type | - |
| `PageContainer` | components/pageContainer.tsx | React Component | 9 |
| `PageContainerProps` | components/pageContainer.tsx | Type | - |
| `PageContent` | components/pageContent.tsx | React Component | 11 |
| `Props` | components/pageContent.tsx | Type | - |
| `SortableList` | components/sortableList.tsx | React Component | 23 |
| `ReorderingHandle` | components/sortableList.tsx | React Component | 10 |
| `getUrlParams` | components/utils/urls.ts | Function | 6 |
| `SUBSCRIPTION_FREE_TRIAL_USAGE_LIMIT` | components/constants.ts | Constant | 1 |

**Example dead code (actual source):**
```typescript
// components/divider.tsx - Entire file deleted in PR
import * as React from "react";

export type DividerProps = {
  label: string;
};

const Divider = ({ label }: DividerProps) => (
  <div className="my-6 flex items-center">
    <div className="h-px flex-1 bg-border" />
    <span className="px-4 text-xs font-medium">{label}</span>
    <div className="h-px flex-1 bg-border" />
  </div>
);

export default Divider;
```

```typescript
// components/utils/urls.ts - Entire file deleted in PR
export const getUrlParams = (searchParams: Record<string, string | string[] | undefined>) =>
  new URLSearchParams(
    Object.entries(searchParams).flatMap(([key, val]) =>
      typeof val === "string" ? [[key, val]] : (val?.map((v) => [key, v]) ?? []),
    ),
  );
```

**Why this dataset matters:**
1. **Verified ground truth** - A human developer identified and removed this code in a merged PR
2. **Production codebase** - Real architectural complexity, not synthetic patterns
3. **Scale** - 576 files tests the limits of context-window-based approaches
4. **Framework patterns** - Next.js App Router conventions (page.tsx, layout.tsx) create entry point detection challenges

---

## 4. Results

### 4.1 Dataset 1: typescript-express-app

| Metric | With Graph | Baseline | Improvement |
|--------|------------|----------|-------------|
| F1 Score | **94.8%** | 56.3% | +68% |
| Precision | 91.0% | 100.0% | -9% |
| Recall | **99.0%** | 39.2% | **+153%** |
| True Positives | 101 | 40 | +61 |
| False Positives | 10 | 0 | +10 |
| False Negatives | 1 | 62 | -61 |
| Tool Calls | **4** | 68 | -94% |
| Runtime | **109s** | 238s | -54% |
| Cost | **$0.40** | $0.79 | -49% |

**Analysis:** On the smaller synthetic dataset, the baseline agent achieves perfect precision but poor recall—it finds functions it's confident about but misses most dead code. The graph-enhanced agent finds nearly everything (99% recall) with slightly lower precision due to some false positives from framework patterns.

### 4.2 Dataset 2: antiwork-helper

| Metric | With Graph | Baseline | Improvement |
|--------|------------|----------|-------------|
| F1 Score | **95.7%** | 28.6% | **+235%** |
| Precision | 100.0% | 100.0% | 0% |
| Recall | **91.7%** | 16.7% | **+449%** |
| True Positives | 11 | 2 | +9 |
| False Positives | 0 | 0 | 0 |
| False Negatives | 1 | 10 | -9 |
| Tool Calls | **6** | 184 | **-97%** |
| Runtime | **42s** | 343s | **-88%** |
| Cost | **$0.11** | $2.64 | **-96%** |
| Iterations | **7** | 28 | **-75%** |

**Analysis:** On the real-world codebase, the performance gap is dramatic. The baseline agent found only 2 of 12 dead code items (16.7% recall) despite making 184 tool calls over 5+ minutes. The graph-enhanced agent found 11 of 12 items (91.7% recall) in 42 seconds with only 6 tool calls.

### 4.3 Baseline Agent Behavior

The baseline agent's tool usage on antiwork-helper (from verbose transcript):

| Tool | Calls | Purpose |
|------|-------|---------|
| Grep | 99 | Searching for function references |
| Read | 47 | Reading source files |
| Glob | 17 | Finding files by pattern |
| Bash | 15 | Running find/ls commands |
| TodoWrite | 4 | Tracking progress |
| Task | 1 | Spawning sub-agent |
| Edit | 1 | Writing report |

**Transcript excerpt (baseline agent reasoning):**
> "Analyzing this TypeScript codebase for dead code requires systematic exploration of the call graph. Let me begin by examining the current state of the workspace..."
> *Creates TODO list: "Build call graph from entry points"*

The agent spent most of its time searching—99 grep calls trying to determine if functions were called anywhere. With 576 files, this search-based approach couldn't achieve coverage within the iteration limit. After 28 iterations and 343 seconds, it had only verified 2 of 12 dead code items.

### 4.4 Graph-Enhanced Agent Behavior

The graph-enhanced agent's tool usage (from verbose transcript):

| Tool | Calls | Purpose |
|------|-------|---------|
| Read | 3 | Reading analysis JSON (with chunking) |
| Bash | 2 | Python script to extract candidates |
| Grep | 1 | Finding dead_code_candidates section |

**Transcript excerpt (with-graph agent):**
> "I'll analyze the codebase for dead code by reading the pre-computed analysis and generating the requested report."

**Complete agent workflow (7 iterations, 42 seconds):**
1. **Read** `.supermodel/dead-code-analysis.json` → Error: 53,158 tokens exceeds 25,000 limit
2. **Grep** for `dead_code_candidates` → Found array structure at line 2
3. **Read** first 50 lines → Understood JSON schema
4. **Bash** Python script to extract all 1,013 candidates → `REPORT.json created successfully`
5. **Read** REPORT.json to verify → Confirmed correct format
6. **Bash** `tail -5 REPORT.json` → Verified `"analysis_complete": true`

The agent immediately pivoted when the file was too large, used grep to understand the structure, then wrote a simple Python script to extract and transform the data. Total time: 42 seconds. Total cost: $0.11.

### 4.5 Scaling Behavior

| Codebase Size | Baseline Recall | Graph Recall | Baseline Cost | Graph Cost |
|---------------|-----------------|--------------|---------------|------------|
| 35 files | 39.2% | 99.0% | $0.79 | $0.40 |
| 576 files | 16.7% | 91.7% | $2.64 | $0.11 |

**Critical insight:** As codebase size increases:
- Baseline recall **degrades** (39% → 17%)
- Baseline cost **increases** ($0.79 → $2.64)
- Graph recall **stays high** (99% → 92%)
- Graph cost **decreases** ($0.40 → $0.11)

The graph pre-computes the expensive work (relationship resolution), so larger codebases don't increase agent effort—they just produce larger JSON files that the agent reads once.

---

## 5. Analysis

### 5.1 Why Does the Graph Help So Much?

1. **Eliminates search** - The agent doesn't need to grep through 576 files to find call sites
2. **Pre-computed relationships** - Import/export resolution is done ahead of time
3. **Entry point detection** - Framework patterns (Next.js pages, API routes) are already identified
4. **Focused context** - Agent sees 325 candidates instead of 1,585 declarations

### 5.2 The One Missed Item

The graph-enhanced agent missed `SUBSCRIPTION_FREE_TRIAL_USAGE_LIMIT`, a constant on line 8 of `components/constants.ts`:

```typescript
export const SUBSCRIPTION_FREE_TRIAL_USAGE_LIMIT = 100;
```

**Root cause:** The Supermodel parser doesn't currently track constant usage within:
- Type annotations (`type Foo = { limit: typeof SUBSCRIPTION_FREE_TRIAL_USAGE_LIMIT }`)
- Template literals (`` `Limit: ${SUBSCRIPTION_FREE_TRIAL_USAGE_LIMIT}` ``)
- Object property initializers

This is a known parser limitation, not an agent limitation.

### 5.3 False Positive Analysis

Supermodel flagged 325 candidates for 12 actual dead items (27:1 ratio). Sources of false positives:

| Category | Description | Example |
|----------|-------------|---------|
| Framework callbacks | React event handlers, Express middleware | `onClick`, `useEffect` callbacks |
| Dynamic imports | `require()` or `import()` with variables | `require(\`./locales/${lang}\`)` |
| Reflection | Decorators, proxy patterns | `@Injectable()` class decorators |
| Test utilities | Functions only called in test files | `createMockUser()` |
| Entry points | Files that are entry points by convention | Next.js `page.tsx` files |

**Key insight:** The 27:1 false positive ratio is acceptable because:
1. The agent achieves **100% precision** in its final output—it uses the graph as a starting point and applies judgment
2. Reviewing 325 candidates is far better than searching 576 files
3. Static analysis provides **candidates for review**, not definitive answers

### 5.4 Threats to Validity

| Threat | Mitigation |
|--------|------------|
| Small sample size (2 datasets) | One synthetic, one real-world with verified ground truth |
| Single model tested | Claude Sonnet 4 is representative of frontier models |
| Prompt sensitivity | Both prompts are minimal and equivalent in complexity |
| Ground truth accuracy | Real-world dataset from merged PR with passing tests |
| Reproducibility | All runs logged with timestamps, configs, and results |

---

## 6. Related Work

### 6.1 Static Analysis Tools

Traditional tools like [Knip](https://knip.dev/) (JavaScript/TypeScript) and [Vulture](https://github.com/jendrikseipp/vulture) (Python) perform dead code detection through static analysis. These tools are deterministic and fast but:

- Require language-specific implementations
- Cannot reason about framework conventions without explicit configuration
- Produce high false positive rates without human tuning

### 6.2 AI-Assisted Code Analysis

Recent work on AI coding assistants (GitHub Copilot, Cursor, Claude Code) shows promise for code understanding tasks. However, these tools typically operate through:

- **RAG-based retrieval** - Embedding similarity doesn't capture call relationships
- **Naive file search** - Grep-based approaches don't scale to large codebases
- **Context window stuffing** - Limited to ~100K tokens of code

Our approach differs by **pre-computing semantic relationships** and providing them as structured data.

### 6.3 Context Engineering

The practice of curating what information an AI receives to maximize effectiveness. Key principles:

1. **Pre-compute expensive operations** - Don't make the agent search
2. **Provide structured data** - JSON over natural language descriptions
3. **Include confidence signals** - Why something is flagged, not just that it is
4. **Filter to relevance** - 325 candidates, not 1,585 declarations

---

## 7. Conclusions

1. **Pre-computed code graphs dramatically improve AI agent performance** on code analysis tasks—5.5x better recall on real-world codebases (16.7% → 91.7%)

2. **Baseline approaches don't scale** - 17% recall on 576 files is not usable in production; the agent made 184 tool calls and still missed 10 of 12 dead code items

3. **Context engineering matters** - Same model, same tools, different input structure yields 5.5x better recall, 30x fewer tool calls

4. **Real-world validation is critical** - Synthetic benchmarks (39% → 99%) hide scaling issues that appear in production (17% → 92%)

5. **Cost efficiency** - Graph approach is 24x cheaper on larger codebases ($0.11 vs $2.64) because the expensive work is pre-computed

6. **Speed** - 8x faster (42s vs 343s) because the agent reads one JSON file instead of searching hundreds of files

---

## 8. Future Work

1. **More datasets** - Additional PRs that removed dead code from other repositories
2. **Cross-validation** - Compare Supermodel results against Knip/Vulture on the same codebases
3. **Parser improvements** - Track constant usage in type annotations and template literals
4. **Framework-specific entry points** - Better detection of Next.js, Remix, and other framework conventions
5. **Confidence scoring** - Rank dead code candidates by likelihood of being true positives

---

## Appendix A: Agent Transcript Excerpts

### A.1 Baseline Agent (First 5 Turns)

```
Turn 1: "Analyzing this TypeScript codebase for dead code requires
        systematic exploration of the call graph..."
        → TodoWrite: Create task list for manual analysis

Turn 2: → Read REPORT.json (empty)
        → Glob **/*.ts, **/*.tsx to find all source files

Turn 3: "Let me explore the codebase structure..."
        → Grep "export function" across codebase (47 matches)
        → Grep "export const" (89 matches)
        → Grep "export class" (12 matches)

Turn 4: "Now I need to trace which of these are called..."
        → Grep "LoginForm" (2 matches - declaration + import)
        → Grep "OnboardingForm" (2 matches)
        → Grep "OAuthButton" (1 match - declaration only) ← FOUND ONE!

Turn 5-28: [Continues searching... 99 grep calls total]
```

**Outcome:** Found 2 of 12 after 184 tool calls, 343 seconds, $2.64

### A.2 With-Graph Agent (Complete Transcript)

```
Turn 1: "I'll analyze the codebase for dead code by reading the
        pre-computed analysis..."
        → Read .supermodel/dead-code-analysis.json
        ← ERROR: 53,158 tokens exceeds 25,000 limit

Turn 2: "The file is too large. Let me search for the candidates..."
        → Grep "dead_code_candidates"
        ← Found at line 2

Turn 3: "Let me read the beginning to understand the structure..."
        → Read (limit=50 lines)
        ← JSON array with {file, name, line, type} objects

Turn 4: "Now I'll extract all candidates with Python..."
        → Bash: python3 script to parse JSON and write REPORT.json
        ← "Found 1013 dead code candidates. REPORT.json created."

Turn 5: "Perfect! Let me verify the report..."
        → Read REPORT.json (first 30 lines)
        ← Confirmed correct format

Turn 6: "Let me check the end of the file..."
        → Bash: tail -5 REPORT.json
        ← "analysis_complete": true

Turn 7: "Excellent! The dead code analysis is complete..."
        [Final summary message]
```

**Outcome:** Found 11 of 12 after 6 tool calls, 42 seconds, $0.11

---

## Appendix B: Raw Data

### B.1 typescript-express-app Baseline Run
```json
{
  "f1_score": 0.563,
  "precision": 1.0,
  "recall": 0.392,
  "true_positives": 40,
  "false_positives": 0,
  "false_negatives": 62,
  "iterations": 33,
  "tool_calls": 68,
  "runtime_seconds": 238,
  "cost": 0.79
}
```

### B.2 typescript-express-app With Graph Run
```json
{
  "f1_score": 0.948,
  "precision": 0.91,
  "recall": 0.99,
  "true_positives": 101,
  "false_positives": 10,
  "false_negatives": 1,
  "iterations": 5,
  "tool_calls": 4,
  "runtime_seconds": 109,
  "cost": 0.40
}
```

### B.3 antiwork-helper Baseline Run
```json
{
  "f1_score": 0.286,
  "precision": 1.0,
  "recall": 0.167,
  "true_positives": 2,
  "false_positives": 0,
  "false_negatives": 10,
  "iterations": 28,
  "tool_calls": 184,
  "runtime_seconds": 343.41,
  "cost": 2.64,
  "tool_usage": {
    "Grep": 99,
    "Read": 47,
    "Glob": 17,
    "Bash": 15,
    "TodoWrite": 4,
    "Task": 1,
    "Edit": 1
  },
  "run_id": "mcpbr_run_20260206_172531",
  "verbose_transcript": true
}
```

### B.4 antiwork-helper With Graph Run
```json
{
  "f1_score": 0.957,
  "precision": 1.0,
  "recall": 0.917,
  "true_positives": 11,
  "false_positives": 0,
  "false_negatives": 1,
  "iterations": 7,
  "tool_calls": 6,
  "runtime_seconds": 42.0,
  "cost": 0.11,
  "tool_usage": {
    "Read": 3,
    "Bash": 2,
    "Grep": 1
  },
  "run_id": "mcpbr_run_20260206_173253",
  "verbose_transcript": true,
  "candidates_reported": 1013
}
```

### B.5 Supermodel Dead Code Analysis (antiwork-helper)
```json
{
  "totalDeclarations": 1585,
  "deadCodeCandidates": 325,
  "aliveCode": 96,
  "entryPoints": 399,
  "analysisMethod": "symbol_level_import_analysis"
}
```

---

## Appendix C: Ground Truth Details

### C.1 antiwork-helper PR #527

**Title:** chore: remove unused code from helper UI
**Author:** @ConstantTime
**Merged:** June 21, 2025
**URL:** https://github.com/antiwork/helper/pull/527

**PR Description:**
> Remove unused UI components and utility functions identified through static analysis to reduce bundle size and maintenance overhead.

**Verification from PR:**
- TypeScript compilation passes
- No remaining imports found via static analysis
- Tests continue to pass (245 tests across 51 files)
- Bundle size reduced without functional impact

**Files Changed:**
| File | Additions | Deletions |
|------|-----------|-----------|
| components/constants.ts | 0 | 2 |
| components/divider.tsx | 0 | 15 |
| components/oauthButton.tsx | 0 | 21 |
| components/pageContainer.tsx | 0 | 9 |
| components/pageContent.tsx | 0 | 11 |
| components/sortableList.tsx | 1 | 42 |
| components/utils/urls.ts | 0 | 6 |
| **Total** | **1** | **106** |

---

## Appendix D: Reproducibility

### D.1 Running the Benchmark

```bash
# Clone mcpbr
git clone https://github.com/greynewell/mcpbr
cd mcpbr

# Install dependencies
uv pip install -e ".[dev]"

# Run baseline
uv run mcpbr run --config config/deadcode-baseline.yaml

# Run with graph
uv run mcpbr run --config config/deadcode-precomputed.yaml
```

### D.2 Generating Supermodel Analysis

**Step 1: Create the repo archive**
```bash
cd /path/to/repo
git archive -o /tmp/repo.zip HEAD
```

This uses `git archive` to create a clean zip without node_modules, .git, or other ignored files.

**Step 2: Submit the analysis job**
```bash
curl -X POST "https://api.supermodeltools.com/v1/analysis/dead-code" \
  -H "X-Api-Key: $SUPERMODEL_API_KEY" \
  -H "Idempotency-Key: $(git rev-parse --short HEAD)" \
  -F "file=@/tmp/repo.zip"
```

Response (job is async):
```json
{"jobId": "abc123", "status": "processing"}
```

**Step 3: Poll for completion**
```bash
curl "https://api.supermodeltools.com/v1/analysis/dead-code?jobId=abc123" \
  -H "X-Api-Key: $SUPERMODEL_API_KEY"
```

Poll every few seconds until `status` is `"completed"`.

**Step 4: Save the result**
```bash
mkdir -p .supermodel
curl "https://api.supermodeltools.com/v1/analysis/dead-code?jobId=abc123" \
  -H "X-Api-Key: $SUPERMODEL_API_KEY" \
  -o .supermodel/dead-code-analysis.json
```

**Output format:**
```json
{
  "dead_code_candidates": [
    {"file": "components/divider.tsx", "name": "Divider", "line": 7, "type": "function"},
    {"file": "components/divider.tsx", "name": "DividerProps", "line": 3, "type": "type"},
    ...
  ],
  "entry_points": [
    {"file": "app/page.tsx", "name": "Page", "line": 5, "type": "function"},
    ...
  ],
  "metadata": {
    "totalDeclarations": 1585,
    "deadCodeCandidates": 325,
    "aliveCode": 96,
    "entryPoints": 399,
    "analysisMethod": "symbol_level_import_analysis"
  }
}
```

The `dead_code_candidates` array is what the agent reads to identify potential dead code.

### D.3 Data Availability

- Benchmark framework: https://github.com/greynewell/mcpbr
- Synthetic dataset: https://github.com/supermodeltools/dead-code-benchmark-corpus
- Real-world ground truth: https://github.com/antiwork/helper/pull/527
- Run logs: Available upon request
