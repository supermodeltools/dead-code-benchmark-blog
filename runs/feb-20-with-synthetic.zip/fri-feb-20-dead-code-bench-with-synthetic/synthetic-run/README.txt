This directory contains the complete output from an mcpbr evaluation run.

Started: 2026-02-20 21:48:43
Config: supermodel-deadcode-ts-express.yaml
Benchmark: supermodel
Model: claude-sonnet-4-20250514
Provider: anthropic

Files:
- config.yaml: Configuration used for this run
- evaluation_state.json: Per-task results and state
- logs/: Detailed execution traces (MCP server logs)

To analyze results:
  mcpbr state --state-dir /Users/jag/Downloads/fri-feb-20-dead-code-bench/synthetic-run

To archive:
  tar -czf results.tar.gz synthetic-run
